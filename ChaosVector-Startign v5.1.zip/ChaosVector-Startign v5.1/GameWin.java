import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GameWin here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GameWin extends World
{

    /**
     * Constructor for objects of class GameWin.
     * 
     */
    public GameWin()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
        
        Greenfoot.playSound("stillAlive.mp3");
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Exit exit = new Exit();
        addObject(exit,398,308);
        Start start = new Start();
        addObject(start,252,309);
        start.setLocation(264,314);
        exit.setLocation(340,320);
        start.setLocation(254,320);
        exit.setLocation(379,317);
        exit.setLocation(393,323);
        exit.setLocation(383,323);
        start.setLocation(271,328);
        start.setLocation(252,324);
        start.setLocation(252,324);
        start.setLocation(324,255);
        exit.setLocation(272,320);
        exit.setLocation(310,323);
        start.setLocation(305,275);
        start.setLocation(310,262);
    }
}

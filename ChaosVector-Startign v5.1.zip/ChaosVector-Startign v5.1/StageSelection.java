import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class StageSelection here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StageSelection extends Images
{
    
    public void StageSelection()
    {
        GreenfootImage image = getImage();  
        image.scale(25, 10);
        setImage(image);
    }
    /**
     * Act - do whatever the StageSelection wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }
}

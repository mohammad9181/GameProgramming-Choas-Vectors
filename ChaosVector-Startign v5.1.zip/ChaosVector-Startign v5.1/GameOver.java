import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GameOver here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GameOver extends World
{
    private String[] message = {
        "You Died", 
        "Its funny to watch you die again and again",
        "This aint falco",
        "chipi chipi chapa chapa dubi dubi daba daba magico mi dubi dubi boom boom boom boom",
        "Just like mari from Omori",
        "What is beauty",
        "By the gods...forgive me.",
        "Nooooooo",
        "Try again next time...",
        "“Take us there, please. A place where light can not haunt us, a place without dreams...Please...",
        "Is this it?",
        "You fought sand Untertale",
        "Chubaca",
        "And at the end of fear... Oblivion.",
        "The Darkness consumes you...",
        "Death, I died again",
        "You have return to the goddess embrace.."
    }; 
        
            
        
    
    /**
     * Constructor for objects of class GameOver.
     * 
     */
    public GameOver()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        int index = Greenfoot.getRandomNumber(message.length);
        String randomMessage = message[index];
        showText(randomMessage, 300, 200);
        
        prepare();
        
        Greenfoot.playSound("gameOver.mp3");
    }

    public void showTextWithBigBlackFont(String message, int x, int y)
    {
        GreenfootImage bg = getBackground();
        Font font = new Font(50);
        bg.setFont(font);
        bg.setColor(Color.WHITE);
        bg.drawString(message,x,y);
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Exit exit = new Exit();
        addObject(exit,532,32);
        exit.setLocation(540,38);
    }
}

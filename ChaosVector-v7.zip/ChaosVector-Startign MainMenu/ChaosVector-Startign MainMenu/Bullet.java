import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bullet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bullet extends Actor
{
    /**
     * Act - do whatever the Bullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    private int speed = 50;
    
    
    
    public Bullet(int speed, int direction)
    {
        GreenfootImage image = getImage();  
        image.scale(10, 5);
        setImage(image);
        
        this.speed = speed;
        setRotation(direction);
        

    }
    
    
    public void act()
    {
        CometDestroy();
        AlienDamage();
        fire();
        
    }
    
    public void fire()
    {   
        
        if(getWorld() == null)
            return;
            
        setLocation(getX(), getY() - 5);
        
        if (isAtEdge()) 
        {
            getWorld().removeObject(this);
        }
    }
    
    public void CometDestroy()
    {
        if(getWorld() == null) 
            return;
            
        Comet c = (Comet)getOneIntersectingObject(Comet.class);
        
        if(c != null)
        {
            c.hit(20);
            getWorld().removeObject(c);
            
            if(getWorld()!=null)
            getWorld().removeObject(this);
            return;
        }
        
    }
    
    public void AlienDamage()
    {
        if(getWorld() == null) 
            return;
            
        Alien a = (Alien)getOneIntersectingObject(Alien.class);
        
        if(a != null)
        {
            a.takeDamage(30);
            
            
            if(getWorld()!=null)
            getWorld().removeObject(this);
            return;
        }
        
    }
}

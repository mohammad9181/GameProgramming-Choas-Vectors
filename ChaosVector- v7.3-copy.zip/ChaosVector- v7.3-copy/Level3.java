import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level3 extends World
{
    
    private int maxAliens = 1;
    private int maxComets = 5;
    private int maxPotion = 1;
    private int maxOctoAliens = 1;
    private int maxStrength = 1;
    private boolean SpawnedOctoAlien = false;
    
    private GreenfootSound backgroundMusic = new GreenfootSound("FinalBoss.mp3");
    /**
     * Constructor for objects of class Level3.
     * 
     */
    public Level3()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 

        //GreenfootImage bg = new GreenfootImage("BG7.png"); // adjust filename as needed
        //bg.scale(getWidth(), getHeight());
        //setBackground(bg);
        
        spawnBoss();
        prepare();
    }
    
    public void started()
    {
        backgroundMusic.playLoop();
    }
    
    public void stopped()
    {
        backgroundMusic.pause();
    }
    
    public void switchToPhaseTwoMusic()
    {
       backgroundMusic.stop();//bgm lvl3
       GreenfootSound phaseTwoMusic = new GreenfootSound("nameless.mp3");
       phaseTwoMusic.playLoop();
    }
    public void act()
    {
        

        
        
        if (getObjects(OctoAlien.class).size() < maxOctoAliens) {
            if (Greenfoot.getRandomNumber(1600) < 2) { // small chance
                spawnOctoAlien();
            }
        }
        
        if (getObjects(Comet.class).size() < maxPotion) {
            if (Greenfoot.getRandomNumber(500) < 2) { // small chance
                spawnHealthPotion();
            }
        }
        
        if (getObjects(StrengthPotion.class).size() < maxStrength) {
            if (Greenfoot.getRandomNumber(1500) < 2) { // small chance
                spawnStrengthPotion();
            }
        }
        
        if (getObjects(Alien.class).size() < maxAliens) {
            if (Greenfoot.getRandomNumber(400) < 2) { // small chance
                spawnAlien();
            }
        }
    }
    public void spawnBoss()
    {
        
        FinalBoss boss = new FinalBoss();
        addObject(boss, 100, 100);
            
            //alien2.setMaxHealth(3500);
            //alien2.setHealth(3500);
            
        BossHp hp = new BossHp(200, 20, boss);
        addObject(hp, 500, 100);
        
    }
    
    private void spawnAlien()
    {
    
        
        Alien alien = new Alien();
        addObject(alien, 400, 100);
            
        alien.setMaxHealth(400);
        alien.setHealth(400);
            
        alien.setSpeed(2);
        alien.setChargeSpeed(4);
        
        AlienHp hpBar = new AlienHp(100, 10, alien);
        addObject(hpBar, alien.getX(), alien.getY() + alien.getImage().getHeight()/2 + 5);


    
        //addObject(new Alien(), getWidth()/2, 50);
        
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Spaceship spaceship = new Spaceship();
        addObject(spaceship,293,304);
        
        HealthBar healthBar = new HealthBar(100,10,spaceship);
        addObject(healthBar, healthBar.getWidth()/2, healthBar.getHeight()/2);
    }
    
    private void spawnHealthPotion()
    {
        HealthPotion h = new HealthPotion();
        int x = Greenfoot.getRandomNumber(getWidth()); // random horizontal
        int y = 0; // top of the world
        addObject(h, x, y);
    }
    
    private void spawnStrengthPotion()
    {
        StrengthPotion s = new StrengthPotion();
        int x = Greenfoot.getRandomNumber(getWidth()); // random horizontal
        int y = 0; // top of the world
        addObject(s, x, y);
    }
    
    public void spawnOctoAlien()
    {
        OctoAlien alien2 = new OctoAlien();
        alien2.isDead = false;
        addObject(alien2, 200, 150);
            
        alien2.setMaxHealth(400);
        alien2.setHealth(400);
            
        OctoAlienHp octoHpBar = new OctoAlienHp(100, 10, alien2);
        addObject(octoHpBar, alien2.getX(), alien2.getY() + alien2.getImage().getHeight()/2 + 5);
        
        
    }
}


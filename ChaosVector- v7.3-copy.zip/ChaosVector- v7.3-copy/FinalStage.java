import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FinalStage here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FinalStage extends Buttons
{
    
    public void FinalStage()
    {
        GreenfootImage image = getImage();  
        image.scale(100, 50);
        setImage(image);
    }
    
    public void act()
    {
        // Add your action code here.
        checkMouse();
        checkClick(new Level3());
        if (Greenfoot.mouseClicked(this)) {
        Levels current = (Levels)getWorld();
        current.stopMusic();             // stop Levels BGM
        Greenfoot.setWorld(new Level3());
    }

    }
    
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HealthBar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BossHp extends FinalBoss
{
    private int width, height;
    private FinalBoss boss;
    

    public BossHp(int width, int height, FinalBoss boss)
    {
        this.width = width;
        this.height = height;
        this.boss = boss;
    }
    
    public int getWidth()
    {
        return width;
    }
    
    public int getHeight()
    {
        return height;
    }
    
    /**
     * Act - do whatever the HealthBar wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        if (boss == null||boss.getWorld() == null)
        {
           if(getWorld()!= null)
            {
                getWorld().removeObject(this);
                
            }
            return;
        }
        
            

            // hpBar stays under alien
            //int bossX = boss.getX();
            //int bossY = boss.getY();
            //int offsetY= boss.getImage().getHeight()/2+height/2+2;
            //setLocation(bossX, bossY + offsetY);
            setLocation(getWorld().getWidth() - 100, -getWorld().getHeight());
        
        draw();
    }
    
    public void draw()
    {
        GreenfootImage myImage = new GreenfootImage( width, height);
        //lost health
        myImage.setColor(Color.YELLOW);
        myImage.fillRect(0, 0,width, height);
        // Draw remaining health
        int healthPercentage = (int)(boss.getStatus() * width);
        myImage.setColor(Color.RED);
        myImage.fillRect( 0, 0, healthPercentage, height);
        
        setImage(myImage);
    }

}
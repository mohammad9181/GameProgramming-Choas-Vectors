import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MainLobby here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MainLobby extends World
{

    /**
     * Constructor for objects of class MainLobby.
     * 
     */
    public MainLobby()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1, false); 
    }
    
    private void prepare()
    {
        GreenfootImage logo = new GreenfootImage("logo.jpg");
        Picture logoPic = new Picture(logo);
        addObject(logoPic, getWidth()/2, 150);
    }
}

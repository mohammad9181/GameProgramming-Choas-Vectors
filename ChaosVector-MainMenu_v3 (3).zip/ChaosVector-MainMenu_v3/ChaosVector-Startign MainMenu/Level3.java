import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level3 extends World
{

    /**
     * Constructor for objects of class Level3.
     * 
     */
    public Level3()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 

        GreenfootImage bg = new GreenfootImage("BG2.jpg"); // adjust filename as needed
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
        
        spawnBoss();
        
        prepare();
    }
    
    public void spawnBoss()
    {
        
        FinalBoss boss = new FinalBoss();
        addObject(boss, 100, 100);
            
            //alien2.setMaxHealth(3500);
            //alien2.setHealth(3500);
            
        BossHp hp = new BossHp(200, 20, boss);
        addObject(hp, 500, 100);
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Spaceship spaceship = new Spaceship();
        addObject(spaceship,293,304);
        
        HealthBar healthBar = new HealthBar(100,10,spaceship);
        addObject(healthBar, healthBar.getWidth()/2, healthBar.getHeight()/2);
    }
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class InfoWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class InfoWorld extends World
{

    /**
     * Constructor for objects of class InfoWorld.
     * 
     */
    public InfoWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 

        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Exit exit = new Exit();
        addObject(exit,536,34);
        info1 info1 = new info1();
        addObject(info1,374,231);
        info2 info2 = new info2();
        addObject(info2,134,190);
        info2.setLocation(192,315);
        info2.setLocation(179,237);
        info1.setLocation(406,260);
        info1.setLocation(273,306);
        info1.setLocation(258,297);
        info1.setLocation(372,272);
        info1.setLocation(252,272);
        info1.setLocation(380,258);
        info2.setLocation(206,306);
        info2.setLocation(167,352);
        info2.setLocation(178,340);
        info2.setLocation(201,268);
        info1.setLocation(377,270);
        info1.setLocation(356,275);
        info1.setLocation(197,334);
        info2.setLocation(240,220);
        info2.setLocation(270,200);
        info2.setLocation(260,264);
        info1.setLocation(233,458);
        info2.setLocation(220,270);
        info1.setLocation(237,284);
        info1.setLocation(444,393);
        info1.setLocation(370,270);
        info1.setLocation(456,264);
        info1.setLocation(220,356);
        info1.setLocation(188,354);
        info2.setLocation(181,351);
        info2.setLocation(187,328);
        info1.setLocation(361,287);
        info2.setLocation(66,356);
        info2.setLocation(66,356);
        info2.setLocation(66,356);
        info1.setLocation(226,264);
        info1.setLocation(336,237);
        info2.setLocation(129,249);
        info2.setLocation(109,262);
        info2.setLocation(-358,455);
        info2.setLocation(128,256);
        info2.setLocation(110,263);
        removeObject(info2);
        Images images = new Images();
        addObject(images,157,372);
        info1.setLocation(290,291);
        info1.setLocation(139,355);
        images.setLocation(144,364);
        info1.setLocation(329,272);
        info1.setLocation(354,219);
        info1.setLocation(325,237);
        info1.setLocation(404,229);
        info1.setLocation(388,237);
    }
}

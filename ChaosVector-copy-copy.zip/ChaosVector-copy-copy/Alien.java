import greenfoot.GreenfootImage;
import greenfoot.Actor;

/**
 * Write a description of class Alien here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Alien extends Actor
{   
    private int speed = 4; // mvt speed of the boss
    private int chargeSpeed = 6; //mvt when charging towards the player
    private int chargeSpeed = 0; //charge CD;
    public Alien()
    {
        GreenfootImage image = getImage();  
        image.scale(180, 80);
        setImage(image);
        
        
    }
    /**
     * Act - do whatever the Alien wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        FollowPlayer();
        ShootPlayer();
        ChargePlayer();
    }
    
    public void FollowPlayer()
    {
        if(!getWorld().getObjects(Spaceship.class).isEmpty()){
            Spaceship spaceship = getWorld().getObjects(Spaceship.class).get(0);
            
            turnTowards(spaceship.getX(), spaceship.getY());
            move(speed);
        }
    }
    
    public void ShootPlayer()//shoot at player at random time
    {
        if( Greenfoot.getRandomNumber(45) == 0){
            if (getWorld() == null)
            return;
            AlienBullet a = new AlienBullet();
            getWorld().addObject(A, getX(), getY());
            
            Spaceship spaceship = getSpaceship();
            if(spaceship!=null)
                a.turnTowards(spaceship.getX(), spaceship.getY());
                
        }
    }
    
    private void ChargePlayer(){
        
    }
}

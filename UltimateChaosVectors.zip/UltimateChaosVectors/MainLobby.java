import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MainLobby here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MainLobby extends World
{
    private  static GreenfootSound backgroundMusic = new GreenfootSound("requiem.mp3");    
     public MainLobby()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1, false); 
        prepare();
        
        Title t = new Title("titlelogo.png");
        addObject(t, getWidth()/2, getHeight()/4);
        
        backgroundMusic.play();
    }
    
    public void started()
    {
        backgroundMusic.playLoop();
    }
    
    public void stopped()
    {
        backgroundMusic.pause();
    }
    
    public void stopMusic()//switching world
    {
        backgroundMusic.stop();
    }
    
    private void prepare()
    {
        //GreenfootImage logo = new GreenfootImage("titlelogo.png");
        //logo.scale(500, 50);
        //addObject(logo,300,300);
        //Picture logoPic = new Picture(logo);
        
        

        Start start = new Start();
        addObject(start,298,184);
        Info info = new Info();
        addObject(info,299,242);
        Exit exit = new Exit();
        addObject(exit,299,316);
        exit.setLocation(302,317);
        info.setLocation(315,251);
        info.setLocation(292,254);
        info.setLocation(299,253);
        start.setLocation(297,176);
        info.setLocation(306,249);
        info.setLocation(304,250);
        info.setLocation(303,250);
        start.setLocation(302,191);
        info.setLocation(303,251);
        info.setLocation(303,251);
        start.setLocation(299,181);
    }
    
}
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class title here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Title extends Actor
{
    /**
     * Act - do whatever the title wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        
    }
    
    public Title(String filename)
    {
        GreenfootImage img = new GreenfootImage(filename); // e.g. "gameTitle.png"
        img.scale(500, 100); // adjust size
        setImage(img);
    }
}

import greenfoot.*;

public class BossTitle extends Actor {
    private int timer = 180; // 3 seconds at 60 fps
    private int alpha = 255; // start fully visible

    public BossTitle(String filename) {
        GreenfootImage img = new GreenfootImage(filename); // e.g. "bossName.png"
        img.scale(600,400); // adjust size
        setImage(img);
        getImage().setTransparency(alpha);
    }

    public void act() {
        timer--;

        // Fade out gradually
        if (timer > 0) {
            alpha = (int)(255 * (timer / 180.0));
            getImage().setTransparency(alpha);
        } else {
            if (getWorld() != null) {
                getWorld().removeObject(this);
            }
        }
    }
}

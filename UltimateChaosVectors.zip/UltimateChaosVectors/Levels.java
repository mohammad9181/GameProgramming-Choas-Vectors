import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Levels here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Levels extends World
{
    private GreenfootSound b = new GreenfootSound("wii.mp3");
    /**
     * Constructor for objects of class Levels.
     * 
     */
    public Levels()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(750, 400, 1); 
        prepare();
        //b.stop();
        
        
        b.play();
    }
    
    public void started()
    {
        b.playLoop();
    }
    
    public void stopped()
    {
         b.pause();
    }
    
    public void stopMusic(){
        b.stop();
    }
     
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {

        StageSelection stageSelection = new StageSelection();
        addObject(stageSelection,561,98);
        Stage1 stage1 = new Stage1();
        addObject(stage1,178,93);
        Stage2 stage2 = new Stage2();
        addObject(stage2,177,215);
        FinalStage finalStage = new FinalStage();
        addObject(finalStage,179,328);
        removeObject(stageSelection);
        StageSelection stageSelection2 = new StageSelection();
        addObject(stageSelection2,548,186);
    }
}

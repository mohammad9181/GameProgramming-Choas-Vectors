import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Spaceship here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Spaceship extends Actor
{
    private int health, maxHealth;
    
    private int speed = 5;
    
    private int potionTimer;
    private boolean isPotionActive = false;
    
    private int bulletSpeed = 25;
    private int bulletDirection = 90;
    
    
    private int fireDelay = 10;
    //private static final int FIRE_DELAY = 10;
    
    private boolean keyDown;
    
    public Bullet bullet;
    
    private boolean enemiesSpawned = false;
    

    public Spaceship()
    {
        GreenfootImage image = getImage();  
        image.scale(50, 40);
        setImage(image);
    
        maxHealth = 750;
        health = maxHealth;
    }
    
    /**
     * Act - do whatever the Spaceship wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        moveAndTurn();
        Boost();
        fireManager();
        if(isPotionActive == true)
        {
            potionTimer++;
            fireDelay -= 1;
            if(potionTimer == 500)
            {
                isPotionActive = false;
                fireDelay += 1;
                potionTimer = 0;
            }
        }
        
        
        if(isGameWin()){
            transitionToGameWin();
        }
        if(isGameOver()){
            transitionToGameOver();
        }
        if(isTheEnd()){
            transitionToTheEnd();
        }
        
        
        }
    
    
    public void moveAndTurn()
    {
        int Boost = 0;        
        if ( Greenfoot.isKeyDown("d")){
            move(speed);
        }
        if ( Greenfoot.isKeyDown("a")){
            move(-speed);
        }
        
        
        if ( Greenfoot.isKeyDown("w")){
            setLocation(getX(), getY() -speed);
        }
        if ( Greenfoot.isKeyDown("s")){
            setLocation(getX(), getY() +speed);
        }
        
        
    }
    
    public void Boost()
    {
        
        
        if (Greenfoot.isKeyDown("shift") && !keyDown) {
            keyDown = true;
            speed += 5;
        } else if (!Greenfoot.isKeyDown("shift") && keyDown) {
            keyDown = false;
            speed -= 5;
        }
    }
    
    public void fireManager()
    {
        
        if (Greenfoot.isKeyDown("space") && fireDelay <= 0) {
            getWorld().addObject(new Bullet(bulletSpeed, bulletDirection), getX(), getY());
            
            fireDelay = 10; //FIRE_DELAY;
            
            GreenfootSound laser = new GreenfootSound("shipLaser.mp3");
            laser.setVolume(20); // volume
            laser.play();
        }
        if (fireDelay > 0) {
             fireDelay--;
         }
        
    }
    
    public int getHealth()
    {
        return health;
    }
    
    public void setHealth(int health)
    {
        this.health = health;
    }
    
    public void addHealth(int health)
    {
        this.health += health;
    }
    
    public double getStatus()
    {
        return (double)health/maxHealth; //stay as double
        
    }

        public void takeDamage(int damage)
    {
        health -= damage;
        if (health <= 0) {
            
            transitionToGameOver();
            
            getWorld().removeObject(this);
            
            
        }
    }
    
    
    
    public void setEnemiesSpawned(boolean spawned)
    {
        enemiesSpawned = spawned;
    }
    
    
    
    public boolean isGameOver()
    {
        World world = getWorld();
        if(world.getObjects(Spaceship.class).isEmpty())
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public void transitionToGameOver()
    {
        World gameOver = new GameOver();
        //stop music when transition
        if (getWorld() instanceof Level1)
        {
                 ((Level1) getWorld()).stopMusic();
            }
            else if (getWorld() instanceof Level2)
            {
                ((Level2) getWorld()).stopMusic();
            }
            else if (getWorld() instanceof Level3) 
            {
                ((Level3) getWorld()).stopMusic();
        }

        Greenfoot.setWorld(gameOver);
        
    }
    
    
    
    public boolean isGameWin()
    {
        World world = getWorld();
        return enemiesSpawned && world.getObjects(Enemies.class).isEmpty();
        
    
    }
    
    public void transitionToGameWin()
    {
        World gameWin = new GameWin();
        //stop music when transition
        if (getWorld() instanceof Level1)
        {
                 ((Level1) getWorld()).stopMusic();
            }
            else if (getWorld() instanceof Level2)
            {
                ((Level2) getWorld()).stopMusic();
            }
           

        Greenfoot.setWorld(gameWin);
        
    }
    
    public boolean isTheEnd()
    {
        World world = getWorld();
        
        if(world instanceof Level3)
        {
             Level3 lvl3 = (Level3) world;
             return lvl3.getBoss() != null && world.getObjects(FinalBoss.class).isEmpty();
        }
        return false;
    
    }
    
    public void transitionToTheEnd()
    {
        World theEnd = new TheEnd();
        //stop music when transition
         if (getWorld() instanceof Level3) 
            {
                ((Level3) getWorld()).stopMusic();
         }

        Greenfoot.setWorld(theEnd);
        
    }
    
    
    public void activatePotion()
    {
        isPotionActive = true;
        
    }
}
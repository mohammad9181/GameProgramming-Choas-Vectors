import greenfoot.*; 

public class Comet extends Enemies
{
    private int size; //size of comet
    //health of comet
    private int stability;
    private int speed; //mvt speed
    
    
    /**
     * Create an asteroid with a given size, random movement direction and 
     * default speed.
     */
    public Comet()
    {
        //removed: this.size = size;
        this.speed = 6;
        this.stability = size;
    
        //random rotation
        //setRotation ( Greenfoot.getRandomNumber(360));
        //scale of image
        GreenfootImage image = getImage();
        image.scale(75, 25);
        setImage(image);
    }
    
  
    public void act()
    {         
        move(speed);
        setRotation(90);
    // if it touches the spaceship, deal damage and remove itself
    Spaceship ship = (Spaceship)getOneIntersectingObject(Spaceship.class);
    if (ship != null) {
        ship.takeDamage(10); // adjust damage as needed
        getWorld().removeObject(this);
        return; // stop further processing this frame
    }

    // remove comet if it reaches bottom
    if (getY() >= getWorld().getHeight() - 1) 
    {
        getWorld().removeObject(this);
    }

    

        
    }
    
    public int getStability() 
    {
        return stability;
    }
    
    
    public void hit(int damage) 
    {
        stability = stability - damage;
        if (stability <= 0) {
            getWorld().removeObject(this);   
        }
    }
    
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Spaceship here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Spaceship extends Actor
{
    private int health, maxHealth;
    
    private int speed = 5;
    
    private int potionTimer;
    private boolean isPotionActive = false;
    
    private int bulletSpeed = 25;
    private int bulletDirection = 90;
    
    
    private int fireDelay = 10;
    //private static final int FIRE_DELAY = 10;
    
    private boolean keyDown;
    
    public Bullet bullet;
    
    private boolean enemiesSpawned = false;
    

    public Spaceship()
    {
        GreenfootImage image = getImage();  
        image.scale(60, 50);
        setImage(image);
    
        maxHealth = 1000;
        health = maxHealth;
    }
    
    /**
     * Act - do whatever the Spaceship wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        moveAndTurn();
        Boost();
        fireManager();
        if(isPotionActive == true)
        {
            potionTimer++;
            fireDelay -= 1;
            if(potionTimer == 500)
            {
                isPotionActive = false;
                fireDelay += 1;
                potionTimer = 0;
            }
        }
        if(isGameWin()){
            transitionToGameWin();
        }
        
    }
    
    public void moveAndTurn()
    {
        int Boost = 0;        
        if ( Greenfoot.isKeyDown("d")){
            move(speed);
        }
        if ( Greenfoot.isKeyDown("a")){
            move(-speed);
        }
        
        
        if ( Greenfoot.isKeyDown("w")){
            setLocation(getX(), getY() -speed);
        }
        if ( Greenfoot.isKeyDown("s")){
            setLocation(getX(), getY() +speed);
        }
        
        
    }
    
    public void Boost()
    {
        
        
        if (Greenfoot.isKeyDown("shift") && !keyDown) {
            keyDown = true;
            speed += 5;
        } else if (!Greenfoot.isKeyDown("shift") && keyDown) {
            keyDown = false;
            speed -= 5;
        }
    }
    
    public void fireManager()
    {
        
        if (Greenfoot.isKeyDown("space") && fireDelay <= 0) {
            getWorld().addObject(new Bullet(bulletSpeed, bulletDirection), getX(), getY());
            
            fireDelay = 10; //FIRE_DELAY;
            
            GreenfootSound laser = new GreenfootSound("shipLaser.mp3");
            laser.setVolume(20); // volume
            laser.play();
        }
        if (fireDelay > 0) {
             fireDelay--;
         }
        
    }
    
    public int getHealth()
    {
        return health;
    }
    
    public void setHealth(int health)
    {
        this.health = health;
    }
    
    public void addHealth(int health)
    {
        this.health += health;
    }
    
    public double getStatus()
    {
        return (double)health/maxHealth; //stay as double
        
    }

        public void takeDamage(int damage)
    {
        health -= damage;
        if (health <= 0) {
            
            getWorld().removeObject(this);
            
            transitionToGameOver();
        }
    }
    
    
    
    public void setEnemiesSpawned(boolean spawned)
    {
        enemiesSpawned = spawned;
    }
    
    
    
    public boolean isGameOver()
    {
        World world = getWorld();
        if(world.getObjects(Spaceship.class).isEmpty())
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public void transitionToGameOver()
    {
        World gameOver = new GameOver();
        Greenfoot.setWorld(gameOver);
        
    }
    
    
    
    public boolean isGameWin()
    {
        World world = getWorld();
        return enemiesSpawned && world.getObjects(Enemies.class).isEmpty();
        
    
    }
    
    public void transitionToGameWin()
    {
        World gameWin = new GameWin();
        Greenfoot.setWorld(gameWin);
        
    }
    
    
    
    
    public void activatePotion()
    {
        isPotionActive = true;
        
    }
}